export class Student {
    Name : string
    Email : string 
    Mobile : string
}
