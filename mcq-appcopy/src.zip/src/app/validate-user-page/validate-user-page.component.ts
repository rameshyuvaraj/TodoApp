import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-validate-user-page',
  templateUrl: './validate-user-page.component.html',
  styleUrls: ['./validate-user-page.component.css']
})
export class ValidateUserPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
